import test, { chromium } from "@playwright/test"
import { channel } from "diagnostics_channel"

test('Launch Browser' , async()=>{

    const browser=await chromium.launch({channel:'chrome' , headless:false})

    const browserContext = await browser.newContext();

    const page = await browserContext.newPage();

await page.goto("http://leaftaps.com/opentaps/control/main");

await page.waitForTimeout(5000)

})