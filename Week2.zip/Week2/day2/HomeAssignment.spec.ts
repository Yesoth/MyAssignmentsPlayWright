import test, { chromium, firefox } from "@playwright/test";

test ("RedBus & Flipkart",async()=>{

  const msBrowser= await chromium.launch();
      const context=await msBrowser.newContext();
      const page=await context.newPage();
      await page.goto("https://www.redbus.in/");
      await page.waitForTimeout(5000);
      const pageTitle1=await page.title();
      console.log(`Page Title of Redbus portal is ${pageTitle1}`)
      const pageUrl1=await page.url();
      console.log(`Page URL for Redbus portal is ${pageUrl1}`)


    const fxbrowser1= await firefox.launch();
      const context1=await fxbrowser1.newContext();
      const page1=await context1.newPage();
      await page1.goto("https://www.flipkart.com");
      await page1.waitForTimeout(8000);

      const pageTitle2=await page1.title();
      console.log(`PageTitle of the Flipkart page is ${pageTitle1}`)

      const pageUrl2=await page1.url();
      console.log(`Page URL of the Flipkart page is ${pageUrl2}`)


})