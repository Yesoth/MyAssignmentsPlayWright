import test from "@playwright/test";

test("Login Page",async({page})=>{

    await page.goto("http://leaftaps.com/opentaps/control/main");
    await page.locator("#username").fill("DemoSalesManager")
    await page.fill("#password","crmsfa")
    await page.click(".decorativeSubmit")
    await page.click(`text='CRM/SFA'`)

    const pageTitle=await page.title()
    console.log(pageTitle)

    await page.waitForTimeout(5000)

})